Invented unsigned package fixture.
